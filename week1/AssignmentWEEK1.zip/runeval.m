imagepath = './test'; % This is the folder where test images are saved. Change the path if needed.
eval_progW1(imagepath)



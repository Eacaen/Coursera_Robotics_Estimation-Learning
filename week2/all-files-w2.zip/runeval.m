testpath = '.'; % This is the folder where test.mat is saved. Change the path if needed.
eval_progW2(testpath)